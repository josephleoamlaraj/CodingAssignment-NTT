package com.microservice.cric.scoreinfo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScoreinfoApplicationTests {

	@Test
	void contextLoads() {
	}

}
