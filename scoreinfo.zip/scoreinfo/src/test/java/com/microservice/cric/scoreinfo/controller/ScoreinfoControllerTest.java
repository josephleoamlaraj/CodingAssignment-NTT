package com.microservice.cric.scoreinfo.controller;

import static org.hamcrest.CoreMatchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.doNothing;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.microservice.cric.scoreinfo.entity.ScoreResult;
import com.microservice.cric.scoreinfo.service.ScoreResultService;

@WebMvcTest(ScoreinfoController.class)
public class ScoreinfoControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ScoreResultService scoreResultService;

    @Autowired
    private ObjectMapper objectMapper;

    private ScoreResult scoreResult1;
    private ScoreResult scoreResult2;

    @BeforeEach
    public void setup() {
        scoreResult1 = new ScoreResult();
        scoreResult1.setMatchId(new Integer(1));
        scoreResult1.setCountry1Name("TeamA");
        scoreResult1.setCountry1Score("254/8");
        scoreResult1.setCountry2Name("TeamB");
        scoreResult1.setCountry2Score("198");
        scoreResult1.setMatchDate("2024-05-30 18:30:11");
        scoreResult1.setResult("TeamA won");
        
        scoreResult2 = new ScoreResult();
        scoreResult2.setMatchId(new Integer(2));
        scoreResult2.setCountry1Name("TeamC");
        scoreResult2.setCountry1Score("310/4");
        scoreResult2.setCountry2Name("TeamD");
        scoreResult2.setCountry2Score("298/8");
        scoreResult2.setMatchDate("2024-06-04 18:30:11");
        scoreResult2.setResult("TeamC won");        
    }

    @Test
    public void givenScoreResultObject_whenSaveScoreResult_thenReturnSavedScoreResult() throws Exception {
        // given - precondition or setup
        given(scoreResultService.saveScoreResult(any(ScoreResult.class)))
                .willAnswer((invocation) -> invocation.getArgument(0));

        // when - action or behavior that we are going test
        ResultActions response = mockMvc.perform(post("/scoreinfo/addscoreresult")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(scoreResult1)));

        // then - verify the result or output using assert statements
        response.andExpect(status().isOk())
                .andExpect(jsonPath("$.matchId", is(scoreResult1.getMatchId())))
                .andExpect(jsonPath("$.matchDate", is(scoreResult1.getMatchDate())))
                .andExpect(jsonPath("$.result", is(scoreResult1.getResult())));
    }

    @Test
    public void givenListOfScoreResults_whenGetAllScoreResults_thenReturnScoreResultsList() throws Exception {
        // given - precondition or setup
        List<ScoreResult> scoreResults = Arrays.asList(scoreResult1, scoreResult2);
        given(scoreResultService.fetchScoreResultList()).willReturn(scoreResults);

        // when - action or behavior that we are going test
        ResultActions response = mockMvc.perform(get("/scoreinfo/getscoreresults"));

        // then - verify the result or output using assert statements
        response.andExpect(status().isOk())
                .andExpect(jsonPath("$.size()", is(scoreResults.size())));
    }

    @Test
    public void givenScoreResultId_whenGetScoreResultById_thenReturnScoreResult() throws Exception {
        // given - precondition or setup
        given(scoreResultService.fetchScoreResultById(scoreResult1.getMatchId())).willReturn(scoreResult1);

        // when - action or behavior that we are going test
        ResultActions response = mockMvc.perform(get("/scoreinfo/getscoreresult/{id}", scoreResult1.getMatchId()));

        // then - verify the result or output using assert statements
        response.andExpect(status().isOk())
                .andExpect(jsonPath("$.matchId", is(scoreResult1.getMatchId())))
                .andExpect(jsonPath("$.matchDate", is(scoreResult1.getMatchDate())))
                .andExpect(jsonPath("$.result", is(scoreResult1.getResult())));
    }

    @Test
    public void givenUpdatedScoreResult_whenUpdateScoreResult_thenReturnUpdatedScoreResult() throws Exception {
        // given - precondition or setup
        ScoreResult updatedScoreResult = new ScoreResult();
        updatedScoreResult.setMatchId(new Integer(1));
        updatedScoreResult.setCountry1Name("TeamA");
        updatedScoreResult.setCountry1Score("254/8");
        updatedScoreResult.setCountry2Name("TeamB");
        updatedScoreResult.setCountry2Score("198");
        updatedScoreResult.setMatchDate("2024-05-30 18:30:11");
        updatedScoreResult.setResult("TeamB won");
        given(scoreResultService.updateScoreResult(any(ScoreResult.class), eq(scoreResult1.getMatchId())))
                .willReturn(updatedScoreResult);

        // when - action or behavior that we are going test
        ResultActions response = mockMvc.perform(put("/scoreinfo/updatescoreresult/{id}", scoreResult1.getMatchId())
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(updatedScoreResult)));

        // then - verify the result or output using assert statements
        response.andExpect(status().isOk())
                .andExpect(jsonPath("$.matchId", is(updatedScoreResult.getMatchId())))
                .andExpect(jsonPath("$.matchDate", is(updatedScoreResult.getMatchDate())))
                .andExpect(jsonPath("$.result", is(updatedScoreResult.getResult())));
    }

    @Test
    public void givenScoreResultId_whenDeleteScoreResult_thenReturn200() throws Exception {
        // given - precondition or setup
        doNothing().when(scoreResultService).deleteScoreResultById(scoreResult1.getMatchId());

        // when - action or behavior that we are going test
        ResultActions response = mockMvc.perform(delete("/scoreinfo/deletescoreresult/{id}", scoreResult1.getMatchId()));

        // then - verify the result or output using assert statements
        response.andExpect(status().isOk());
    }
}
